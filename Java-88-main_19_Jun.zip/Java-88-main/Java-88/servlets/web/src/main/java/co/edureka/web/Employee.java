package co.edureka.web;

public class Employee {
	private Integer empno;
	private String empname;
	private Float empsal;

	public Integer getEmpno() {
		return empno;
	}

	public void setEmpno(Integer empno) {
		this.empno = empno;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public Float getEmpsal() {
		return empsal;
	}

	public void setEmpsal(Float empsal) {
		this.empsal = empsal;
	}

}
