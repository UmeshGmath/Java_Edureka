package co.edureka.services;

public class Nums {
	public int add(int x, int y) {
		System.out.println("inside add() method");
		return x+y;
	}
	public float sub(float a, float b) {
		System.out.println("inside sub() method");
		return a-b;
	}
}
