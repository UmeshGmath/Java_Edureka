/**
 * TempConvertSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.w3schools.www.xml;

public interface TempConvertSoap extends java.rmi.Remote {
    public java.lang.String fahrenheitToCelsius(java.lang.String fahrenheit) throws java.rmi.RemoteException;
    public java.lang.String celsiusToFahrenheit(java.lang.String celsius) throws java.rmi.RemoteException;
}
