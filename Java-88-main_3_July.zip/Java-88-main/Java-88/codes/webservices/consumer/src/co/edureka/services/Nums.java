/**
 * Nums.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package co.edureka.services;

public interface Nums extends java.rmi.Remote {
    public int add(int x, int y) throws java.rmi.RemoteException;
    public float sub(float a, float b) throws java.rmi.RemoteException;
}
