package co.edureka.ems.services;

import co.edureka.ems.entity.Employee;

public interface EmployeeService {
	public Employee searchEmployeeById(Integer eno);
}
